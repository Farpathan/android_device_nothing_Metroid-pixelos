/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */
/*
 * Copyright (c) Qualcomm Innovation Center, Inc. All rights reserved.
 */

#ifndef _MISC_ADSP_SLEEPMON_H
#define _MISC_ADSP_SLEEPMON_H

#include <linux/types.h>
#include <linux/ioctl.h>

#define ADSPSLEEPMON_DEVICE_NAME "/dev/msm_adsp_sleepmon"

#define ADSPSLEEPMON_IOCTL_AUDIO_VER_1 0x1

enum adspsleepmon_audio_activity_cmd {
    ADSPSLEEPMON_AUDIO_ACTIVITY_START = 1,
    ADSPSLEEPMON_AUDIO_ACTIVITY_STOP,
    ADSPSLEEPMON_AUDIO_ACTIVITY_LPI_START,
    ADSPSLEEPMON_AUDIO_ACTIVITY_LPI_STOP,
};

struct adspsleepmon_ioctl_audio {
    __u32 version;
    __u32 command;
};

#define ADSPSLEEPMON_IOCTL_MAGIC 'a'
#define ADSPSLEEPMON_IOCTL_AUDIO_ACTIVITY _IOW(ADSPSLEEPMON_IOCTL_MAGIC, 1, struct adspsleepmon_ioctl_audio)

#endif /* _MISC_ADSP_SLEEPMON_H */
