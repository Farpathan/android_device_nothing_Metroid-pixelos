/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */
/*
 * Copyright (c) 2023-2024 Qualcomm Innovation Center, Inc. All rights reserved.
 */

#ifndef _UAPI_QTI_SMMU_PROXY_H
#define _UAPI_QTI_SMMU_PROXY_H

#include <linux/types.h>
#include <linux/ioctl.h>

struct csf_version {
	__u32 arch_ver;
	__u32 max_ver;
};

#define QTI_SMMU_PROXY_IOC_MAGIC 'S'
#define QTI_SMMU_PROXY_GET_VERSION_IOCTL \
	_IOR(QTI_SMMU_PROXY_IOC_MAGIC, 1, struct csf_version)

#endif /* _UAPI_QTI_SMMU_PROXY_H */
