/* SPDX-License-Identifier: GPL-2.0-only WITH Linux-syscall-note */
#ifndef _UAPI_LINUX_MSM_ION_H
#define _UAPI_LINUX_MSM_ION_H

#include <linux/types.h>
#include <linux/ioctl.h>

#define ION_HEAP(bit) (1 << (bit))
#define ION_FLAG_CACHED 1
#define ION_FLAG_CACHED_NEEDS_SYNC 2
#define ION_FLAG_SECURE 4

enum ion_heap_ids {
	INVALID_HEAP_ID = -1,
	ION_CP_MM_HEAP_ID = 8,
	ION_SECURE_HEAP_ID = 9,
	ION_SECURE_DISPLAY_HEAP_ID = 10,
	ION_SPSS_HEAP_ID = 13,
	ION_SECURE_CARVEOUT_HEAP_ID = 14,
	ION_AUDIO_HEAP_ID = 21,
	ION_ADSP_HEAP_ID = 22,
	ION_SYSTEM_HEAP_ID = 25,
	ION_HEAP_ID_RESERVED = 31
};

#define ION_DISPLAY_HEAP_ID 2
#define ION_FLAG_CP_SEC_DISPLAY (1 << 25)
#define ION_FLAG_CP_CAMERA (1 << 26)
#define ION_FLAG_CP_CAMERA_PREVIEW (1 << 27)

#endif /* _UAPI_LINUX_MSM_ION_H */
